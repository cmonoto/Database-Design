1. First unzip it and under the directory with all the unzipped files you can type 

      javac P1.java

to compile the java code. type

      java P1

to execute the program. At this moment, you will see a prompt in your console